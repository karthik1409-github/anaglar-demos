const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken')

let patients = [
  {"patientid": 1, "patientname": "Patient1", "email": "patient1@gmail.com"},
  {"patientid": 2, "patientname": "Patient2", "email": "patient2@yahoo.com"},
  {"patientid": 3, "patientname": "Patient3", "email": "patient3@hotmail.com"},
  {"patientid": 4, "patientname": "Patient4", "email": "patient4@gmail.com"},
  {"patientid": 5, "patientname": "Patient5", "email": "patient5@yahoo.com"}
];

let users = [
  {"username": "user1", "password": "password_123", "role": "admin"},
  {"username": "user2", "password": "password_123", "role": "physician"},
  {"username": "user3", "password": "password_123", "role": "nurse"}
];


function verifyToken(req, res, next) {
  if(!req.headers.authorization) {
    return res.status(401).send('Unauthorized request')
  }
  let token = req.headers.authorization.split(' ')[1]
  if(token === 'null') {
    return res.status(401).send('Unauthorized request')    
  }
  let payload = jwt.verify(token, 'secretKey')
  if(!payload) {
    return res.status(401).send('Unauthorized request')    
  }
  req.userId = payload.subject
  next()
}

router.get('/allpatients', verifyToken, (req,res) => {
  res.json(patients);
})

// router.post('/register', (req, res) => {
//   let userData = req.body
//   let user = new User(userData)
//   user.save((err, registeredUser) => {
//     if (err) {
//       console.log(err)      
//     } else {
//       let payload = {subject: registeredUser._id}
//       let token = jwt.sign(payload, 'secretKey')
//       res.status(200).send({token})
//     }
//   })
// })

router.post('/login', (req, res) => {
  let userData = req.body
  
  let result = users.find(u => u.username == userData.username && u.password == userData.password);


  if(result == undefined)
  {
    res.status(401).send('Invalid credentials')
  }
  else
  {
    let payload = {subject: result.username}
    let token = jwt.sign(payload, 'secretKey')
    res.status(200).send({token, role:result.role})
  }
  
  //users.findOne({username: userData.username}, (err, user) => {

    // if (err) 
    // {
    //   console.log(err)    
    // } 
    // else 
    // {
    //   if (!user) {
    //     res.status(401).send('Invalid username')
    //   } else 
    //   if (user.password !== userData.password) {
    //     res.status(401).send('Invalid Password')
    //   } else {
    //     let payload = {subject: user._id}
    //     let token = jwt.sign(payload, 'secretKey')
    //     res.status(200).send({token})
    //   }
    // }
  //})
})

module.exports = router;