import { RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { LoginComponent } from './login.component';
import { AuthenticatedComponent } from './authenticated.component';
import { AuthorizedComponent } from './authorized.component';
import { ErrorComponent } from './error.component';

import { AuthGuard } from './auth.guard';

const routes = [
    { path: '', component: HomeComponent},
    { path: 'home', component: HomeComponent},
    { path: 'login', component: LoginComponent },
    { 
        path: 'authenticated', 
        component: AuthenticatedComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'authorized', 
        component: AuthorizedComponent,
        canActivate: [AuthGuard]
    },
    { path: '**', component: ErrorComponent}
];

export default RouterModule.forRoot(routes);