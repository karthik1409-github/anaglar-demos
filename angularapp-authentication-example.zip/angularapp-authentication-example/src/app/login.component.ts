import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
  ]
})
export class LoginComponent implements OnInit {

  public user: any = {
    "username": "",
    "password": ""
  };
  public error: string;

  constructor(private svc: AuthService, private router: Router) { }

  ngOnInit(): void {
  }

  public Login(): void
  {
      this.svc.Login(this.user).subscribe(
        (data: any) => 
        {
          this.svc.AuthenticationToken = data.token;
          this.svc.IsAuthenticated = true;
          this.svc.UserRole = data.role;
          this.router.navigate(['/authenticated']);
        },
        (error: any) => this.error = error.error
      );
  }

}
