import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { LoginComponent } from './login.component';
import { AuthenticatedComponent } from './authenticated.component';
import { AuthorizedComponent } from './authorized.component';
import { ErrorComponent } from './error.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms';

import appRoutes from './app.routes';
import { from } from 'rxjs';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoggerInterceptor } from './logger.interceptor';
import { TokenInterceptor } from './token.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AuthenticatedComponent,
    AuthorizedComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule, appRoutes, HttpClientModule, FormsModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoggerInterceptor, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
