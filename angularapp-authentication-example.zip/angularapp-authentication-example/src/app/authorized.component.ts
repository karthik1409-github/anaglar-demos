import { Component, OnInit } from '@angular/core';
import { AuthService } from  './auth.service';

@Component({
  selector: 'app-authorized',
  templateUrl: './authorized.component.html',
  styles: [
  ]
})
export class AuthorizedComponent implements OnInit {

  constructor(public svc: AuthService) { }

  ngOnInit(): void {
  }

}
