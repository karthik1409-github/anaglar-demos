import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Patient } from '../models/patient';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PatientService 
{
  constructor(private httpsvc: HttpClient) { }

  public GetAllPatients(): Observable<Patient[]>
  {
      console.log("GetAllPatients() called in PatientService..");
      //GET http://localhost:3000/patients
      return this.httpsvc.get<Patient[]>('http://localhost:3000/patients');
  }
  public GetPatientById(id: number): Observable<string>
  {
      //GET http://localhost:3000/patients?id=...
      return this.httpsvc.get<Patient>('http://localhost:3000/patients?id=' +id)
          .pipe(map(value => value[0].id +"---->" +value[0].name +"---->" +value[0].email));
  }

  public AddPatient(p: Patient): Observable<Patient>
  {
    //POST http://localhost:3000/patients
    return this.httpsvc.post<Patient>('http://localhost:3000/patients', p);
  }

  public GetPatientVisits(pid: number): Observable<any>
  {
    return this.httpsvc.get<any>('http://localhost:3000/patients?id=' +pid)
      .pipe(map(value => value[0].visits));
  }
}
