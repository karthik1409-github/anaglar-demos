import { PatientListComponent } from './patient-list/patient-list.component';
import { SearchPatientComponent } from './search-patient/search-patient.component';
import { ErrorComponent } from './error/error.component';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { PatientComponent } from './patient/patient.component';
import { PatientVisitComponent} from './patient-visit/patient-visit.component';

//create an array of routes
const appRoutes = [
    { path: '', component: HomeComponent},
    { path: 'patientlist', component: PatientListComponent},
    { path: 'search', component: SearchPatientComponent},
    { path: 'patientvisit/:pid', component: PatientVisitComponent},
    // { path: 'patient/:pname/visits/:docname', component: PatientVisitComponent},
    { 
        path: 'doctor', 
        loadChildren: () => import('./doctor/doctor.module').then(m => m.DoctorModule)
    },
    
    { 
        path: 'nurse', 
        loadChildren: () => import('./nurse/nurse.module').then(m => m.NurseModule)
    },


    { path: '**', component: ErrorComponent}
];

//return a RouterModule with all the routing services and the routes
export default RouterModule.forRoot(appRoutes);

