import { Component, OnInit } from '@angular/core';
import { Patient } from '../models/patient';
import { PatientService } from '../services/patient.service';

@Component({
  selector: 'app-search-patient',
  templateUrl: './search-patient.component.html',
  styleUrls: ['./search-patient.component.css']
})
export class SearchPatientComponent implements OnInit {

  public patientid: number;
  public p: Patient = new Patient();

  constructor(private patientsvc: PatientService) { }

  ngOnInit(): void {
  }

  public SearchPatient(): void
  {
      this.patientsvc.GetPatientById(this.patientid).subscribe(
        (p: string) => console.log(p),
        (error: any) => console.log("Error in searching patient")
      );
  }

}
