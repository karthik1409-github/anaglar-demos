import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoggerService 
{
  constructor() 
  { 
    console.log("LoggerService instance created");
  }

  public LogMessage(message: string): void
  {
    console.log("LoggerService logged: " +message);
  }
}
