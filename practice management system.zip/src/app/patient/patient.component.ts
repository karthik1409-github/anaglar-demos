import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { Patient } from '../models/patient';
import { LoggerService } from '../logger.service';

import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

  @Input()
  public patientinfo: Patient;

  @Input()
  public currentdate: Date;

  @Output()
  public morepatientinfo: EventEmitter<number> = new EventEmitter<number>();

  public GenerateNotification(): void
  {
    this.morepatientinfo.emit(this.patientinfo.id);
  }

  //declaring the dependency
  constructor(private logger: LoggerService, private route: ActivatedRoute) 
  { 
    this.logger.LogMessage("Hello from PatientComponent");
  }

  ngOnInit(): void 
  {
    
  }

}
