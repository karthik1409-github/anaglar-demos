export class Patient
{
    constructor(
        public id: number=0, 
        public name: string="", 
        public email: string="",
        public visits: any = "")
    {
        
    }
}