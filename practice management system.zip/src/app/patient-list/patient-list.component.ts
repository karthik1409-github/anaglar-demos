import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from '../models/patient';
import { PatientService } from '../services/patient.service';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit 
{
  public ob: Observable<Patient[]>;
  public patients: Patient[] = [];

  constructor(private patientsvc: PatientService) { }

  GetAllPatients(): void
  {
    this.ob = this.patientsvc.GetAllPatients();
    // this.ob.subscribe(
    //   this.OnDataReceived,    //SUCCESS CALLBACK
    //   this.OnError            //ERROR CALLBACK
    // );

    this.ob.subscribe(
      (p: Patient[]) => this.patients = p,
      (error: any) => console.log("Error in receiving patient data")
    );
  }

  // private OnDataReceived(p: Patient[]): void
  // {
  //   console.log("Patient data received");
  //   this.patients = p;
  //   console.log(this.patients.length);
  // } 
  // private OnError(error: any): void
  // {
  //   console.log("Error in receiving patient data");
  // }

  // private GetMoreInfo(patientid: number): void
  // {
  //   //code to connect to the DB and get more info
  //   //of the patientid
  //   console.log("Getting more info of patient with id: " +patientid);
  // }

  // RespondToMoreInfo(pid: number): void
  // {
  //     this.GetMoreInfo(pid);
  // }

  ngOnInit(): void 
  {
  }
}
