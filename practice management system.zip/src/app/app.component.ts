import { Component } from '@angular/core';
import { Patient } from './models/patient';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  //model
  apptitle: string = 'Practice-Management-System (PMS)';

  //model
  patientname: string = "ABC";

  patientnames: string[] = ["ABC", "XYZ", "LMN", "MNO"];


  

  constructor()
  {
      
  }

  // public ChangeTitle(source: any): void
  // {
  //   this.title = "***CHANGED***";
  //   console.log(source.target.innerHTML);
  // }
  

  
}
