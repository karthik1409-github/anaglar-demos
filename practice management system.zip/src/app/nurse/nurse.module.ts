import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NurseComponent } from '../nurse.component';
import nurseRoutes from './nurse.routes';



@NgModule({
  declarations: [NurseComponent],
  imports: [
    CommonModule, nurseRoutes
  ]
})
export class NurseModule 
{ 
  constructor()
  {
    console.log("NurseModule loaded");
  }
  
}
