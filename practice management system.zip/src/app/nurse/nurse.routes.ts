import { RouterModule } from '@angular/router';
import { NurseComponent } from '../nurse.component';

const routes = [
    { path: '', component: NurseComponent}
];

export default RouterModule.forChild(routes);