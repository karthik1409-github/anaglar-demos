import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DoctorComponent } from '../doctor.component';
import doctorRoutes from './doctor.routes';


@NgModule({
  declarations: [DoctorComponent],
  imports: [
    CommonModule,
    doctorRoutes
  ]
})
export class DoctorModule 
{ 
  constructor()
  {
    console.log("DoctorModule loaded");
  }
}
