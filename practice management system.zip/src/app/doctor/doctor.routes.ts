import { RouterModule } from '@angular/router';
import { DoctorComponent } from '../doctor.component';

const routes = [
    { path: '', component: DoctorComponent}
];

export default RouterModule.forChild(routes);