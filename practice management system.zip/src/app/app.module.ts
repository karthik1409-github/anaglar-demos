import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import {FormsModule} from '@angular/forms';
import { SquarePipe } from './square.pipe';
import { PatientListComponent } from './patient-list/patient-list.component';
import { PatientComponent } from './patient/patient.component';

import { HttpClientModule } from '@angular/common/http';
import { SearchPatientComponent } from './search-patient/search-patient.component';
import { ErrorComponent } from './error/error.component';
import appRoutes from './app.routes';
import { HomeComponent } from './home/home.component';
import { PatientVisitComponent } from './patient-visit/patient-visit.component';
// import { DoctorModule } from './doctor/doctor.module';
// import { NurseModule } from './nurse/nurse.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserRegistrationComponent,
    SquarePipe,
    PatientListComponent,
    PatientComponent,
    SearchPatientComponent,
    ErrorComponent,
    HomeComponent,
    PatientVisitComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule, 
    appRoutes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule 
{ 
  constructor()
  {
    console.log("AppModule constr called");
  }
}
