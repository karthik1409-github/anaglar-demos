import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PatientService } from '../services/patient.service';

@Component({
  selector: 'app-patient-visit',
  templateUrl: './patient-visit.component.html',
  styleUrls: ['./patient-visit.component.css']
})
export class PatientVisitComponent implements OnInit {

  public visits: any;
  constructor(private svc: PatientService, private route: ActivatedRoute ) { }

  ngOnInit(): void 
  {
    //one way to read the route parameters
    //console.log(this.route.snapshot.params.pid);

    //another way to read the route parameters
    this.route.params.subscribe(
      (paramlist) => console.log(paramlist["pid"])
    );

    this.svc.GetPatientVisits(this.route.snapshot.params.pid).subscribe(
      (data) => this.visits = data
    )
  }
}
