import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'square'
})
export class SquarePipe implements PipeTransform {

  transform(x: number, param1?: string, param2?:string): number 
  {
      console.log("Square pipe transform called");
      console.log("param1 is: " +param1);
      console.log("param2 is: " +param2);
      return (x * x);
  }
}
