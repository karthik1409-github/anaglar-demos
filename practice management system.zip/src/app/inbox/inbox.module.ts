import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InboxComponent } from './inbox.component';
import { ComposeMailComponent } from '../compose-mail/compose-mail.component';



@NgModule({
  declarations: [InboxComponent, ComposeMailComponent],
  imports: [
    CommonModule
  ],
  exports: [InboxComponent, ComposeMailComponent]
})
export class InboxModule { }
