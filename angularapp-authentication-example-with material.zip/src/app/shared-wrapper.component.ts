import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';

import { AuthService } from './auth.service';
import { ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

const SMALL_SCREEN_SIZE = 720;

@Component({
  selector: 'app-shared-wrapper',
  templateUrl: './shared-wrapper.component.html',
  styleUrls: ['./shared-wrapper.component.css']
})
export class SharedWrapperComponent implements OnInit {

  public isScreenSmall: boolean;
  public selectedoption: string = "";

  @ViewChild('x')
  public matselection: any;
  constructor(private breakpointobserver: BreakpointObserver, public svc: AuthService, 
    private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void 
  {
    this.breakpointobserver.observe(
      [`(max-width: ${SMALL_SCREEN_SIZE}px)`]
    )
    .subscribe((state: BreakpointState) => {
      this.isScreenSmall = state.matches;
    });
  }

  DoSomething(eventsource: any): void
  {
    
    console.log(this.matselection.selectedOptions.selected[0]?.value);
    if(this.matselection.selectedOptions.selected[0]?.value == "inbox")
    {
      this.router.navigate(['inbox'],{ relativeTo: this.route });
    }
    if(this.matselection.selectedOptions.selected[0]?.value == "notification")
    {
      this.router.navigate(['notification']);
    }
  }

}
