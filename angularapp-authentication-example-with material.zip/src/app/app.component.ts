import { Component } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  constructor(public svc: AuthService, private router: Router){}

  public Logout(): void
  {
    this.svc.Logout();
    this.router.navigate(['/login']);
  }

  title = 'angularapp-authentication-exa;mple';
}
