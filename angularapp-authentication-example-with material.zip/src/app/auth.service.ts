import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService 
{
  private token: string = "";
  private role: string = "";
  private isAuthenticated: boolean = false;

  constructor(private http: HttpClient) { }

  public set AuthenticationToken(token: string)
  {
    this.token = token;
  }
  public get AuthenticationToken()
  {
    return this.token;
  }

  public set UserRole(role: string)
  {
    this.role = role;
  }
  public get UserRole()
  {
    return this.role;
  }

  public set IsAuthenticated(isAuthenticated: boolean)
  {
    this.isAuthenticated = isAuthenticated;
  }
  public get IsAuthenticated()
  {
    // if(Object.keys(this.token).length == 0)
    if(this.token == "")
    {
      this.isAuthenticated = false;
    }
    else
    {
      this.isAuthenticated = true;
    }
    return this.isAuthenticated;
  }

  public Login(userdata: any): Observable<any>
  {
    return this.http.post<any>('http://localhost:3000/api/login', userdata);
  }

  public Logout(): void
  {
    this.isAuthenticated = false;
    this.token = "";
    this.role = "";
  }

  public GetAllPatients(): Observable<any>
  {
    return this.http.get('http://localhost:3000/api/allpatients')
  }
}