// import { Component, OnInit } from '@angular/core';
// import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';

// import { AuthService } from './auth.service';

// const SMALL_SCREEN_SIZE = 720;

// @Component({
//   selector: 'app-side-nav',
//   templateUrl: './side-nav.component.html',
//   styleUrls: ['./side-nav.component.css']
// })
// export class SideNavComponent implements OnInit {

//   public isScreenSmall: boolean;
//   constructor(private breakpointobserver: BreakpointObserver, public svc: AuthService) { }

//   ngOnInit(): void 
//   {
//     this.breakpointobserver.observe(
//       [`(max-width: ${SMALL_SCREEN_SIZE}px)`]
//     )
//     .subscribe((state: BreakpointState) => {
//       this.isScreenSmall = state.matches;
//     });
//   }

// }
