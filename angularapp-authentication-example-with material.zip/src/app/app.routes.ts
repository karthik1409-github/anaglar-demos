import { RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { LoginComponent } from './login.component';
import { AuthenticatedComponent } from './authenticated.component';
import { AuthorizedComponent } from './authorized.component';
import { ErrorComponent } from './error.component';

import { AuthGuard } from './auth.guard';

const routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full'},
    { path: 'home', component: HomeComponent},

    
    //this route is to lazily load the shared-wrapper module
    { 
        path: 'sharedwrapper', loadChildren: () => import('./shared-wrapper/shared-wrapper.module').then(m => m.SharedWrapperModule)
    },
    //this route is to lazily load the shared-wrapper module



    { path: 'login', component: LoginComponent },
    { 
        path: 'authenticated', 
        component: AuthenticatedComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'authorized', 
        component: AuthorizedComponent,
        canActivate: [AuthGuard]
    },
    { path: '**', component: ErrorComponent}
];

export default RouterModule.forRoot(routes);