import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-authenticated',
  templateUrl: './authenticated.component.html',
  styles: [
  ]
})
export class AuthenticatedComponent implements OnInit {

  public patients: any[];

  constructor(private svc: AuthService) { }

  public GetAllPatients(): void
  {
    this.svc.GetAllPatients().subscribe(
      (data) => this.patients = data,
      (error) => console.log(error)
    );
  }

  ngOnInit(): void {
  }

}
