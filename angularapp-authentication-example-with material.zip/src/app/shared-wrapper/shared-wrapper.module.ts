import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedWrapperComponent } from '../shared-wrapper.component';
// import { SideNavComponent } from '../side-nav.component';
import { ToolbarComponent } from '../toolbar.component';

import { SharedMaterialModule } from '../shared-material/shared-material.module';
import sharedwrapperroutes from './shared-wrapper.routes';

@NgModule({
  declarations: [
    SharedWrapperComponent, 
    // SideNavComponent, 
    ToolbarComponent
  ],
  imports: [
    CommonModule,
    SharedMaterialModule,
    sharedwrapperroutes
  ],
  exports: [
    SharedWrapperComponent,
    // SideNavComponent, 
    ToolbarComponent,
    SharedMaterialModule
  ]
})
export class SharedWrapperModule { }
