import { RouterModule } from '@angular/router';
import { SharedWrapperComponent } from '../shared-wrapper.component';
import { InboxComponent } from '../inbox.component';

const routes = [
    { 
        path: '', 
        component: SharedWrapperComponent,
        children: [
            { 
                path: 'inbox', component: InboxComponent
            }
        ]
    },
];

export default RouterModule.forChild(routes);

