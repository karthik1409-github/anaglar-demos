import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';

//import the custom validator function
import { forbiddenValidator } from '../customvalidators/forbiddenname.validator';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  fg: FormGroup = new FormGroup({
    username: new FormControl('', [Validators.required,Validators.minLength(3), forbiddenValidator]),
    password: new FormControl('', Validators.required),
    rememberme: new FormControl(true),
    role: new FormControl('SELECT')
  });

  constructor() { }

  Login(eventsource: any): void
  {
    // console.log(eventsource.target);
    // console.log(this.fg.value);
    // console.log(`User name: ${this.fg.value.username}`);
    // console.log(`Password: ${this.fg.value.password}`);
    
    // console.log(this.fg.get('username').errors);

    
    if(this.fg.invalid == false)    //if all the form controls have passed their validation
    {
      //call the REST api and pass the form control values
    }
    else
    {
      //display a validation summary
    }

    // if(this.fg.get('username').errors == null)
    // {
    //   console.log("ALL VALIDATIONS ON USERNAME SUCCESSFUL");
    // }
    // else
    // {
    //   console.log("Some validation error occured on username");
    // }
  }

  SetValues(): void
  {
    //call a REST api
    //get values from REST API
    //display the values in each form control
    // this.fg.setValue({
    //   username: 'KARTHIK',
    //   // password: 'password_123',
    //   // rememberme: true,
    //   // role: 'doc'
    // });

    this.fg.patchValue({
      username: 'KARTHIK',
      role: 'doc'
    });
  }

  ngOnInit(): void {
  }

}
