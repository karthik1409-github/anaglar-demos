import { AbstractControl } from '@angular/forms';

export function forbiddenValidator(control: AbstractControl): {[key:string]: any} | null
{
    //get the form control value
    let value = control.value;

    //validate the value in any manner
    if(value == "admin")
    {
        //validation fails
        return { 'forbiddenname': 'Value: ' +control.value };
    }
    
    return null;        //validation passes
}
